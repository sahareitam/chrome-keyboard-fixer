window.location.href = "https://www.google.co.il/";
